
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const file = path.join(__dirname, 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter);

async function initDB() {
  await db.read();
  db.data = db.data || { products: [], users: [], orders: [] };
  if(db.data.products.length===0){
    db.data.products=[
      {id:'p1',title:'Floral Summer Dress',price:25,image:'https://images.unsplash.com/photo-1520975925604-9b2a6e5d1b2a?w=800&q=80',category:'Dresses'},
      {id:'p2',title:'Casual White Tee',price:10,image:'https://images.unsplash.com/photo-1520975911504-4e6a9f6b7b3f?w=800&q=80',category:'Tops'},
      {id:'p3',title:'High Waist Jeans',price:35,image:'https://images.unsplash.com/photo-1542365887-7e0b3b8e2f6f?w=800&q=80',category:'Jeans'},
      {id:'p4',title:'Sporty Sneakers',price:40,image:'https://images.unsplash.com/photo-1528701800484-5d6f5a6f4b7f?w=800&q=80',category:'Shoes'},
      {id:'p5',title:'Classic Handbag',price:30,image:'https://images.unsplash.com/photo-1514996937319-344454492b37?w=800&q=80',category:'Bags'}
    ];
  }
  if(db.data.users.length===0){
    db.data.users=[
      {id:'u1',name:'Ali',email:'ali@example.com',password:'1234',role:'user',wallet:50,cart:[],orders:[]},
      {id:'admin',name:'Admin',email:'admin@example.com',password:'admin',role:'admin',wallet:0,cart:[],orders:[]}
    ];
  }
  await db.write();
}
initDB();

app.listen(process.env.PORT || 3000,()=>console.log("Sheein USD wallet complete running"));
