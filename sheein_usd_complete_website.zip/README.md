
# Sheein USD Wallet Complete Website

## Features
- Products in USD
- Wallet system (manual top-up via admin)
- Admin panel: /admin.html (admin@example.com / admin)
- User can shop and checkout using wallet

## Deploy to Render
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/<YOUR_USERNAME>/sheein-usd-wallet)

Replace <YOUR_USERNAME> with your GitHub username.
